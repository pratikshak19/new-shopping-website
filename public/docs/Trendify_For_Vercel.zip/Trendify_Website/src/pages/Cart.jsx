import { useState } from 'react'
import { Link } from 'react-router-dom'
import { formatINR, formatRentalDate } from '../data/products'
import { smartCartSuggestion } from '../lib/styleEngine'
import { useStore } from '../context/StoreContext'
import ProductImage from '../components/ProductImage'
import { Icon } from '../components/Icons'

export default function Cart() {
  const { cartDetailed, totals, updateQty, removeFromCart, applyCoupon, coupon, clearCoupon, giftWrap, setGiftWrap, coupons, visibleProducts, addToCart, budgetLock, user } = useStore()
  const smart = smartCartSuggestion(
    cartDetailed.map((l) => l.product),
    visibleProducts,
    budgetLock || 0
  )
  const [code, setCode] = useState('')
  const [err, setErr] = useState('')

  const apply = (e) => {
    e.preventDefault()
    const res = applyCoupon(code)
    setErr(res.ok ? '' : res.error)
  }

  if (!cartDetailed.length) {
    return (
      <div className="empty">
        <h2>Your bag is empty</h2>
        <p>Looks like you haven&apos;t added anything yet.</p>
        <Link className="btn btn-primary" to="/shop" style={{ marginTop: 16 }}>
          Start shopping
        </Link>
      </div>
    )
  }

  return (
    <div className="wrap">
      <div className="page-hero">
        <h1>Your bag</h1>
        <p style={{ color: 'var(--muted)' }}>{totals.count} item{totals.count > 1 ? 's' : ''}</p>
      </div>
      <div className="cart-layout">
        <div>
          {smart && (
            <aside className="smart-cart">
              <p>🛍️ {smart.text}</p>
              {smart.product && (
                smart.product.rentalOnly ? (
                  <Link className="btn btn-ghost" to={`/product/${smart.product.id}?mode=rent`}>
                    Rent {smart.product.name} · {formatINR(smart.product.rental?.perDay || 0)}/day
                  </Link>
                ) : (
                  <button className="btn btn-ghost" type="button" onClick={() => addToCart(smart.product.id)}>
                    Add {smart.product.name} · {formatINR(smart.product.price)}
                  </button>
                )
              )}
            </aside>
          )}
          {cartDetailed.map((line, i) => (
            <article key={`${line.id}-${line.mode}-${line.color}-${line.size}-${line.rentalStart || ''}-${i}`} className="cart-item">
              <Link to={`/product/${line.id}${line.mode === 'rent' ? '?mode=rent' : ''}`}>
                <ProductImage src={line.product.image} alt={line.product.name} />
              </Link>
              <div>
                <div className="pcard-brand">{line.product.brand}</div>
                <Link to={`/product/${line.id}${line.mode === 'rent' ? '?mode=rent' : ''}`} className="pcard-name">
                  {line.product.name}
                </Link>
                <p style={{ fontSize: 13, color: 'var(--muted)', margin: '4px 0 6px' }}>
                  {line.color} · {line.size}
                </p>
                {line.mode === 'rent' ? (
                  <div className="rental-line-note">
                    <strong>Rental · {line.quote?.days || line.rentalDays} days</strong>
                    <span>
                      {formatRentalDate(line.rentalStart)} · pickup {formatRentalDate(line.rentalEnd)}
                    </span>
                    <span>
                      Rental {formatINR(line.unitPrice)} + refundable deposit {formatINR(line.deposit / line.qty)} each
                    </span>
                  </div>
                ) : (
                  <p className="rental-line-note"><strong>Purchase</strong></p>
                )}
                <div className="qty">
                  <button onClick={() => updateQty(i, line.qty - 1)}>-</button>
                  <span>{line.qty}</span>
                  <button onClick={() => updateQty(i, line.qty + 1)}>+</button>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="price">{formatINR(line.lineTotal)}</div>
                <button onClick={() => removeFromCart(i)} style={{ marginTop: 12, color: 'var(--muted)' }} aria-label="Remove">
                  <Icon.trash style={{ width: 18, height: 18 }} />
                </button>
              </div>
            </article>
          ))}
        </div>
        <aside className="summary">
          <h3 className="serif" style={{ fontSize: 24, marginBottom: 8 }}>
            Price details
          </h3>
          <div className="row">
            <span>MRP</span>
            <span>{formatINR(totals.mrpTotal)}</span>
          </div>
          <div className="row">
            <span>Product discount</span>
            <span style={{ color: 'var(--ok)' }}>-{formatINR(totals.productSave)}</span>
          </div>
          {totals.rentalSubtotal > 0 && (
            <div className="row">
              <span>Rental fees included</span>
              <span>{formatINR(totals.rentalSubtotal)}</span>
            </div>
          )}
          {totals.rentalDeposit > 0 && (
            <div className="row">
              <span>Refundable rental deposit</span>
              <span>{formatINR(totals.rentalDeposit)}</span>
            </div>
          )}
          <div className="row">
            <span>Coupon</span>
            <span style={{ color: 'var(--ok)' }}>-{formatINR(totals.discount)}</span>
          </div>
          <div className="row">
            <span>Delivery</span>
            <span>{totals.shipping === 0 ? 'Free' : formatINR(totals.shipping)}</span>
          </div>
          <div className="row">
            <span>Gift wrap</span>
            <span>{totals.wrap ? formatINR(totals.wrap) : '—'}</span>
          </div>
          <label className="filter-opt" style={{ margin: '8px 0' }}>
            <input type="checkbox" checked={giftWrap} onChange={(e) => setGiftWrap(e.target.checked)} />
            Gift wrap this bag (₹49)
          </label>
          <div className="row total">
            <span>Total</span>
            <span>{formatINR(totals.grand)}</span>
          </div>
          <form className="coupon" onSubmit={apply}>
            <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Coupon code" />
            <button className="btn btn-ghost" type="submit">
              Apply
            </button>
          </form>
          {err && <div className="error">{err}</div>}
          {coupon && (
            <p style={{ fontSize: 13, color: 'var(--ok)' }}>
              {coupon.code} · {coupon.label}{' '}
              <button onClick={clearCoupon} style={{ textDecoration: 'underline' }}>
                remove
              </button>
            </p>
          )}
          <p style={{ fontSize: 12, color: 'var(--muted)', margin: '8px 0 14px' }}>
            Active: {coupons.filter((c) => c.active).map((c) => c.code).join(' · ')}
          </p>
          <Link className="btn btn-primary btn-block" to={user ? '/checkout' : '/login?next=/checkout'}>
            {user ? 'Checkout' : 'Sign in to checkout'}
          </Link>
        </aside>
      </div>
    </div>
  )
}
