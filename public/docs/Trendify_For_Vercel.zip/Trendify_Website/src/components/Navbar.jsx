import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { CATEGORIES, MEGA, ROLE_META } from '../data/products'
import { useStore } from '../context/StoreContext'
import { Icon } from './Icons'

export default function Navbar() {
  const { totals, wishlist, user, unread, settings, compare } = useStore()
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  const portal = user?.role === 'admin' ? ROLE_META.admin.home : null

  const go = (e) => {
    e.preventDefault()
    navigate(q.trim() ? `/shop?q=${encodeURIComponent(q.trim())}` : '/shop')
    setOpen(false)
  }

  return (
    <>
      <div className="announce">{settings.announcement}</div>
      <header className="nav">
        <div className="wrap nav-row">
          <button className="icon-btn menu-btn" onClick={() => setOpen((o) => !o)} aria-label="Menu" aria-expanded={open} aria-controls="mobile-nav">
            <Icon.menu />
          </button>
          <Link to="/" className="brand" onClick={() => setOpen(false)}>
            <img src="/images/logo.png" alt="Trendify" />
            <div className="brand-name">Tren<span>dify</span></div>
          </Link>
          <nav className="nav-links" aria-label="Primary">
            <NavLink to="/shop">Shop</NavLink>
            <NavLink to="/collections">Collections</NavLink>
            <NavLink to="/rentals">Rent Clothes</NavLink>
            <NavLink to="/style">Style</NavLink>
            <NavLink to="/festivals">Festivals</NavLink>
            <NavLink to="/kits">Kits</NavLink>
            {CATEGORIES.slice(0, 3).map((c) => (
              <div className="mega-wrap" key={c.id}>
                <NavLink to={`/shop?cat=${c.id}`}>{c.name}</NavLink>
                {MEGA[c.id] && (
                  <div className="mega" role="menu">
                    {MEGA[c.id].map((item) => (
                      <Link key={item} to={`/shop?cat=${c.id}&q=${encodeURIComponent(item)}`} role="menuitem">
                        {item}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <NavLink to="/offers">Offers</NavLink>
          </nav>
          <form className="search" onSubmit={go} role="search">
            <Icon.search />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search kurtas, sneakers, earbuds..." aria-label="Search Trendify" />
          </form>
          <div className="nav-acts">
            {portal && (
              <Link to={portal} className="chip on" style={{ height: 36 }}>
                {ROLE_META[user.role].label}
              </Link>
            )}
            <Link to="/notifications" className="icon-btn" title="Alerts" aria-label={`Alerts${unread ? `, ${unread} unread` : ''}`}>
              <Icon.pin />
              {unread > 0 && <span className="badge">{unread}</span>}
            </Link>
            <Link to={user ? '/profile' : '/login'} className="icon-btn" title={user ? user.name : 'Account'} aria-label={user ? `Account, ${user.name}` : 'Sign in'}>
              <Icon.user />
            </Link>
            <Link to="/wishlist" className="icon-btn" title="Wishlist" aria-label={`Wishlist${wishlist.length ? `, ${wishlist.length} items` : ''}`}>
              <Icon.heart />
              {wishlist.length > 0 && <span className="badge">{wishlist.length}</span>}
            </Link>
            <Link to="/cart" className="icon-btn" title="Bag" aria-label={`Bag${totals.count ? `, ${totals.count} items` : ''}`}>
              <Icon.bag />
              {totals.count > 0 && <span className="badge">{totals.count}</span>}
            </Link>
          </div>
        </div>
        <div className={`mobile-drawer wrap ${open ? 'open' : ''}`} id="mobile-nav">
          <form className="search" onSubmit={go} style={{ marginBottom: 10 }}>
            <Icon.search />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search Trendify" />
          </form>
          <Link to="/shop" onClick={() => setOpen(false)}>All products</Link>
          <Link to="/collections" onClick={() => setOpen(false)}>New Collections</Link>
          <Link to="/rentals" onClick={() => setOpen(false)}>Rent Clothes</Link>
          <Link to="/style" onClick={() => setOpen(false)}>Style assistant</Link>
          <Link to="/quiz" onClick={() => setOpen(false)}>60-second quiz</Link>
          <Link to="/festivals" onClick={() => setOpen(false)}>Festival radar</Link>
          <Link to="/kits" onClick={() => setOpen(false)}>Lifestyle kits</Link>
          <Link to="/own" onClick={() => setOpen(false)}>I already own this</Link>
          {CATEGORIES.map((c) => (
            <Link key={c.id} to={`/shop?cat=${c.id}`} onClick={() => setOpen(false)}>
              {c.name}
            </Link>
          ))}
          <Link to="/offers" onClick={() => setOpen(false)}>Offers</Link>
          <Link to="/insider" onClick={() => setOpen(false)}>Insider</Link>
          <Link to="/compare" onClick={() => setOpen(false)}>Compare ({compare.length})</Link>
          <Link to="/orders" onClick={() => setOpen(false)}>My orders</Link>
          <Link to="/login" onClick={() => setOpen(false)}>Sign in</Link>
        </div>
      </header>
    </>
  )
}
